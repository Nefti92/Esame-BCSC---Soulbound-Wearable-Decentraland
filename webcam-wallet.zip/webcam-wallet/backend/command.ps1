$env:Path += ";C:\Program Files\Blender Foundation\Blender 4.5\"
blender -b Maschera.blend --python BlenderScript.py

# Modifica percorso Blender in base a dove hai installato il programma